
function changeComponent(component) {
	document.adminForm.component.value = component;
	document.adminForm.submit();
}