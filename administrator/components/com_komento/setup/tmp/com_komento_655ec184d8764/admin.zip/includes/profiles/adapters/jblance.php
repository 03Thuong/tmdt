<?php
/**
* @package		Komento
* @copyright	Copyright (C) 2010 - 2016 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Komento is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');

class KomentoProfilesJblance extends KomentoBase
{
	protected $profile = null;

	public function __construct($profile)
	{
		if (!$this->exists()) {
			return;
		}

		$this->profile = $profile;
	}

	public function exists()
	{
		//include this helper file to make the class accessible in all other PHP files
		$filename = JPATH_ADMINISTRATOR . '/components/com_jblance/helpers/jblance.php';

		//include this helper file to make the class accessible in all other PHP files
		$filename2 = JPATH_ADMINISTRATOR . '/components/com_jblance/helpers/link.php';

		if (!JFile::exists($filename) || !JFile::exists($filename2)) {
			return false;
		}

		require_once($filename);
		require_once($filename2);

		return true;
	}

	public function getAvatar()
	{
		$avatar = '';
		//get the JoomBri picture
		$db = KT::db();

		$query = "SELECT thumb FROM `#__jblance_user` WHERE `user_id` = " . $db->Quote($this->profile->id);

		$db->setQuery($query);
		$jbpic = $db->loadResult();

		$imgpath = JBPROFILE_PIC_PATH . '/' . $jbpic;
		$imgurl = JBPROFILE_PIC_URL . $jbpic . '?' . time();

		$avatar = JURI::root().'components/com_jblance/images/nophoto_sm.png';

		if (JFile::exists($imgpath)){
			$avatar = $imgurl;
		}

		return $avatar;
	}

	public function getLink()
	{
		return LinkHelper::GetProfileLink($this->profile->id);
	}
}