<?php
/**
* @package		Komento
* @copyright	Copyright (C) Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Komento is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');

KT::import('admin:/views/views');

class KomentoViewLanguages extends KomentoAdminView
{
	/**
	 * Retrieves a list of known languages
	 *
	 * @since	3.0
	 * @access	public
	 */
	public function getLanguages()
	{
		$model = KT::model('Languages');
		$result = $model->discover();

		if ($result !== true) {

			$return = base64_encode('index.php?option=com_komento&view=languages');

			return $this->ajax->reject($result->error);
		}

		return $this->ajax->resolve();
	}

	/**
	 * Post processing after updating languages
	 *
	 * @since	3.0
	 * @access	public
	 */
	public function update()
	{
		return $this->ajax->resolve();
	}

	/**
	 * Displays a confirmation to delete a language
	 *
	 * @since	3.0
	 * @access	public
	 */
	public function confirmDelete()
	{
		$theme = KT::themes();

		$ids = $this->input->get('cid', [], 'array');

		$theme->set('ids', $ids);
		$content = $theme->output('admin/languages/dialog.delete');

		return $this->ajax->resolve($content);
	}
}
