Komento
.require()
.script(
	'shared/elements',
	'shared/foundry'
)
.library('dialog')
.done(function($) {

});
