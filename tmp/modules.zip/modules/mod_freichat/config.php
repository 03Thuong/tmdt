<?php

// No direct access
defined('_JEXEC') or die;

/**
 * Module common configuration
 * @package Module Module for Joomla! 3.X
 * @version 1.0.3
 * @author Codologic
 * @license  GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @copyright Codologic 2010-2019
 * @since 2019
 */

define("API_BASE_PATH", "https://nodelb.freichat.com/api");
// define("API_BASE_PATH", "https://localhost:8080/api");