<?php
/**
 * @package     mod_db8sitelastmodified
 * @author      Peter Martin, https://db8.nl
 * @copyright   Copyright (C) 2014-2022 Peter Martin. All rights reserved.
 * @license     GNU General Public License version 2 or later.
 */

defined('_JEXEC') or die;

?>
<ul class="db8sitelastmodified<?php echo $moduleclass_sfx; ?>">
    <li>
        <?php echo $formated_date;?>
    </li>
</ul>